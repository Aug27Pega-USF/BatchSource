package com.driver.enus;

public enum AccountType {
	NONE, CUSTOMER, EMPLOYEE, ADMIN;
}
